function setup() {
  createCanvas(400, 400);
  var liczba = prompt("PODAJ LICZBE");
  textSize(30);
  text(`analiza liczby  ${liczba}`, 10,36);
  text(" jest dodatnia",10,90);
  text(" jest ujemna",10,140);
  text("jest zero",10,190);
  noFill();
  if(liczba>0){
    rect(5,60,200,40);
  }
  if(liczba<0){
    rect(5,110,200,40);
  }
  if(liczba == 0){
    rect(5,160,200,40)
  }
}

function draw() {

}